// import LifeCycleMethodsA from "./Documentation/LifeCycleMethods/LifecycleMethod";
// import ParentCompoents from "./Documentation/PureComponents/ParentComponent";
// import MemoParentCompoents from "./Documentation/Memo/MemoPaent";
// import RefCompoents from "./Documentation/Ref";
// import ParentRefCompoents from "./Documentation/Ref/ClassRef/Parent";
// import ParentForwardRefCompoents from "./Documentation/Ref/ForwardRef/Parent";
// import ReactPortalComponents from "./Documentation/ReactPortal";
// import ParentComponentWithErrorBoundary from "./Documentation/ErrorBoundary";
// import HigherOrderComponentParent from "./Documentation/HighOrderComponents/Parent";
// import UseStateHookComponents from "./Documentation/Hooks/UseStateHook";
// import UseReducerFunction from "./Documentation/Hooks/UseReducer.js";
// import UseCallBackHooks from "./Documentation/Hooks/UseCallback.js/index.js";
// import UseMemoComponents from "./Documentation/Hooks/UseMemo.js";
// import UseRefHookComponents from "./Documentation/Hooks/UseRefHooks.js";
import CountTitleComponents from "./Documentation/Hooks/CustomeHooks.js/CountTitle.js";

function App() {
  return (
    <>
      <CountTitleComponents />
    </>
  );
}

export default App;

// http://localhost:3000/  -  MainPage url